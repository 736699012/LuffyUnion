package com.example.taobaounion.model.bean;

public interface IBaseInfo {

    String getPict_url();
    String getTitle();
    String getUrl();
}
