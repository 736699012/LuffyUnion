package com.example.taobaounion.model.bean;

public interface ILinearInfo extends IBaseInfo{

    String getZk_final_price();

    long getCoupon_amount();

    long getVolume();
}
