package com.example.taobaounion.model.bean;

import java.util.List;

public class History {

    private List<String> mHistoryList;

    public List<String> getHistoryList() {
        return mHistoryList;
    }

    public void setHistoryList(List<String> historyList) {
        mHistoryList = historyList;
    }
}
